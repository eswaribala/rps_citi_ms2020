package com.citi.insurance.customerapi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.insurance.customerapi.models.Customer;
import com.citi.insurance.customerapi.services.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	//adding the customer
	@PostMapping("/customers")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
	{
		return this.customerService.addCustomer(customer);
	}

	//retrieve all customers
	@GetMapping("/customers")
	public List<Customer> findAllCustomers()
	{
		return this.customerService.getAllCustomers();
		
	}
	
}
