package com.citi.insurance.customerapi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.insurance.customerapi.models.Customer;
import com.citi.insurance.customerapi.services.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	//adding the customer
	@PostMapping("/customers")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
	{
		return this.customerService.addCustomer(customer);
	}

	//retrieve all customers
	@GetMapping("/customers")
	public List<Customer> findAllCustomers()
	{
		return this.customerService.getAllCustomers();
		
	}
	
	@PutMapping("/customers")
	public @ResponseBody Customer updateCustomer(@RequestBody Customer customer)
	{
	      return this.customerService.updateCustomer(customer);
		
	}
	
	@DeleteMapping("/customers/{customerId}")
	public ResponseEntity<?> deleteCustomer(@PathVariable("customerId") int customerId)
	{
	       if(this.customerService.deleteCustomer(customerId))
	    	  return  ResponseEntity.ok("CustomerId"+customerId+"Not deleted / not available");
	       else
	    	   return ResponseEntity.ok("CustomerId"+customerId+"deleted");
		
	}
	
	@GetMapping("/customers/{customerId}")
	public Customer findCustomerById(@PathVariable("customerId") int customerId)
	{
		return this.customerService.getCustomerById(customerId);
		
	}
	
	
}
