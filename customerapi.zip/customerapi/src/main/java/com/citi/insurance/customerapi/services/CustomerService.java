package com.citi.insurance.customerapi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.insurance.customerapi.models.Customer;
import com.citi.insurance.customerapi.repositories.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;
	
	//insert 
	
	public Customer addCustomer(Customer customer)
	{
		return customerRepo.save(customer);
	}
	
	//retrieve all customer objects (select all)
	
	public List<Customer> getAllCustomers()
	{
		return customerRepo.findAll();
	}
	
	//retrieve customer by id (select with where)
	public Customer getCustomerById(int customerId)
	{
		return customerRepo.findById(customerId).orElse(null);
	}
	
	//update customer information
	public Customer updateCustomer(Customer customer)
	{
		return customerRepo.save(customer);
	}
	
	//delete the customer by id
	public boolean deleteCustomer(int customerId)
	{
		boolean status=false;
		customerRepo.deleteById(customerId);
		Customer customer=getCustomerById(customerId);
		if(customer!=null)
			status=true;
		return status;
		
		
	}
	

}
