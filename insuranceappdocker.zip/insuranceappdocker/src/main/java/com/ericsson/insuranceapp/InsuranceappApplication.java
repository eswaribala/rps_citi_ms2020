package com.ericsson.insuranceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceappApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceappApplication.class, args);
	}

}
